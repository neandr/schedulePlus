#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
    Copyright (C) 2015 - 2021 gWahl
'''
#  **schedule+**     sonoffDevices.py         /cVersion/2021-11-29_21/

# Based on
# https://stackoverflow.com/questions/53633014/python-socket-getting-lan-connected-server-host-names

import socket, sys, json
import urllib.request
from timeit import default_timer as timer

from threading import Thread

def getIPbase():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ipBase = s.getsockname()[0]
    s.close()

    ipBase = ipBase.split('.')
    return "%s.%s.%s" % (ipBase[0],ipBase[1],ipBase[2])

def _checkIPs(ipBase, ip, ipDevice):
    _ip = "%s.%s" % (ipBase, str(ip))
    try:
        s = socket.gethostbyaddr(_ip)
        if ("sonoff-" in s[0]) or ("tasmota-" in s[0]):
            ipDevice[ip] = {}
            ipDevice[ip]['name']= s[0]
    except:
        pass

def deviceStatus(ipBase, ip, details_Devices, failed_Devices):
    _ip = "%s.%s" % (ipBase,str(ip))
    modes = {
        'status': '/cm?cmnd=status', \
        'state': '/cm?cmnd=state', \
        'module': '/cm?cmnd=module', \
    }

    try:
        #print("# \n  ---- details_Device ip:: ", _ip)
        with urllib.request.urlopen('http://' + _ip + modes['status']) as response:
            STATUS = json.loads(response.read())['Status']
            #print("#\n ... get device status::", ip, STATUS, STATUS['Module']")

        with urllib.request.urlopen('http://' + _ip + modes['state']) as response:
            STATE = json.loads(response.read())
            #print("#\n... get device state::", ip, STATE)

        with urllib.request.urlopen('http://' + _ip + modes['module']) as response:
            MODULE = json.loads(response.read())['Module']
            #print("#\n ... get device module::", ip, MODULE)

        if 'DeviceName' in STATUS:
            dName = STATUS['DeviceName']
            details_Devices[dName] = { 'ip': ip, "module": MODULE, \
                "STATUS": STATUS, "STATE": STATE}
        else:
            FriendlyName = STATUS['FriendlyName']
            details_Devices[FriendlyName[0]] = { 'ip': ip, "module": MODULE, \
                "STATUS": STATUS, "STATE": STATE}

        failed_Devices.pop(ip)  #remove this 'ip' from <dict> to only hold failed IPs

    except:
        pass

def getDevices(ipfirst,iplast):
    print("#  sonoffDevices  ... getDevices:", ipfirst, iplast)

    details_Devices = {}
    failed_Devices = {}

    ipBase = getIPbase()

    for ip in range(ipfirst,iplast+1):  ## ---> failed_Devices
        worker = Thread(target = _checkIPs, args = (ipBase, ip, failed_Devices))
        worker.start()
        worker.join(timeout=0.05)

    #print("#  ... got failed_Devices", type(failed_Devices), str(failed_Devices), "\n")


    for ip in range(ipfirst,iplast+1):
        if ip in failed_Devices:          ## { 62: 'sonoff-4320.fritz.box' }
            worker = Thread(target = deviceStatus, args = (ipBase, ip, details_Devices, failed_Devices))
            worker.start()
            worker.join(timeout=0.3)

    #print("#\n\n\n  ... got details_Devices", str(details_Devices), "\n")
    #print("#  ... devs active ::", type(details_Devices), str(details_Devices), "\n")
    #print("#  ... IPs failed ::", str(failed_Devices), "\n")   # type(failed_Devices),

    return(details_Devices, failed_Devices)

if __name__ == '__main__':
    # limit range for performance !
    ipfirst = 2
    iplast  = 65

    if (len(sys.argv) == 3):
        ipfirst = int(sys.argv[1])
        iplast = int(sys.argv[2])

    start0 = timer()
    devices, failedDevices = getDevices(ipfirst, iplast)
    stop0 = timer()

    print(json.dumps(devices, indent=3))
    print("#  ... devices:", type(devices), str(devices))
    print("#  ... ipFailed:", type(failedDevices), str(failedDevices))
    print ("\n *** elapse time *** {(stop0 - start0):{8}.{3}} sec")

    # Example for devices:
    '''
        [[50, 'sonoff-4316.fritz.box'],
        [51, 'sonoff-3126.fritz.box'],
          ...
    '''
