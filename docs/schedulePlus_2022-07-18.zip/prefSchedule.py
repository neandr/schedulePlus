#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
    Copyright (C) 2015 - 2021 gWahl
'''
#  **schedule+**     prefSchedule.py          /cVersion/2021-08-02/

import sys, json, socket, platform

xprefs = {}
xprefs['version'] = "0.8.6"
xprefs['vDate']   = "2022-06-25"

users = {}
# --- user data ------------------------------------------------
#  will be loaded from  xprefsJsonUser  (see below)
# ------------------------------------------------ user data ---

# --- system ---------------------------------------------------
xprefs['jPrefs'] =  'data/jPrefs.json'
xprefsJsonUser =  'data/jPrefs.user.json'

#  xprefs['port'] = 5004

xprefs['switchTime'] = 0

xprefs['piDocs'] = "https://neandr.github.io/piSchedule/"
xprefs['news'] = xprefs['piDocs'] + 'newsplus.txt'  #  'news.txt'
xprefs['newsDate'] = ''

xprefs['logInfoName'] = "logs/Info.log"
xprefs['logSysName'] =  "logs/System.log"
xprefs['logging'] = "trace"   # console.trace or similar like log, error .. etc
xprefs['dayPlanActive'] = "true"

xprefs['weekSchedule'] = {
        "Friday": "--",
        "Monday": "--",
        "Saturday": "--",
        "Sunday": "--",
        "Thursday": "--",
        "Tuesday": "--",
        "Wednesday": "--"
      }
# --------------------------------------------------- system ---

def getServer(routerName):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ip = s.getsockname()[0]

    routerIP = socket.gethostbyname(routerName)
    s.close()

    #print("#  ... getServer :: ", ip, routerIP)
    return ip, routerIP


def getPrefs():
    old= {}
    try:
        with open(xprefs['jPrefs']) as data_file:
           old = json.load(data_file)
    except:
        pass
        print(" *** NEW Start, no 'jPrefs' file found!")

    users= {}
    try:
        with open(xprefsJsonUser) as data_file:
           users = json.load(data_file)
    except:
        pass
        print(" *** NEW Start, no 'User jPrefs' file found!")

    for p in old:
        xprefs[p] = old[p]

    for p in users:
        if p == "weekSchedule":
            if isinstance(users[p], dict) == True and len(users[p]) > 0:
                xprefs[p] = users[p]
        else:
            xprefs[p] = users[p]

    #  go for system prefs
    xprefs['server'], xprefs['routerIP'] = getServer(xprefs['routerName'])
    ip_parts = xprefs['server'].split('.')
    xprefs['baseIP'] = "%s.%s.%s." % (ip_parts[0],ip_parts[1],ip_parts[2])

    xprefs['platform'] = platform.uname()[1] + " -- " + str(platform.platform()).replace("'","")

    # write updated prefs file
    f = open(xprefs['jPrefs'], 'w')
    f.write(json.dumps(xprefs))
    f.close()

    #print("#  ... prefSchedule prefs ::", json.dumps(xprefs, indent=2, sort_keys = True))
    return xprefs

#-------------------------------------------
if __name__ == '__main__':
    prefs =  getPrefs()
    print("prefSchedule ::", str(prefs))
