#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
      **schedule+**     schedulePlus.py          /cVersion/2022-07-10_17
'''
cVersion = "0.8.6"


import platform, logging, os, sys, re, signal, shutil  #, traceback
import subprocess, socket

import inspect

import threading
from threading import Thread, Event

import bottle
from bottle import Bottle, run, static_file, route, \
    view, template, \
    get, post, request, debug, \
    error, abort, html_escape

import urllib
import urllib.parse

import datetime
from datetime import date
from datetime import datetime
from datetime import timedelta

import time
from time import sleep

from dateutil.parser import *

import json, random, glob

from sonoffDevices import getDevices
from localDevices import ipDevices

from apscheduler.schedulers.background import BackgroundScheduler

bw='\033[1m'                  # bold
br='\033[1;38;5;196m'         # bold red
ba='\033[1;38;5;16;48;5;15m'  # bold black on white
bg='\033[1;38;5;28;48;5;7m'   # bold green on white
bb='\033[1;38;5;21;48;5;7m'   # bold blue on white
e0='\033[0m'                  # reset/normal


# Debugging helper:  get calling stack
def stacker():
    msg = ("||CALLER '" + inspect.stack()[2][3] + "' "\
        + " <-- " + inspect.stack()[2][1] + "::" + str(inspect.stack()[2][2]) \
        + " <-- " + inspect.stack()[3][1] + "::" + str(inspect.stack()[3][2]) \
        + " <-- " + inspect.stack()[4][1] + "::" + str(inspect.stack()[4][2]) )
    logSys(msg)

class goBottle(Bottle):
    ''' Starting Bottle is used with this "class goBottle()".
        This is to catch the standard bottle error handling and
        allow 'private' error processing.
        See also: https://stackoverflow.com/a/39818780/325976
    '''
    def default_error_handler(app, res):
        #stacker()
        err = '<p><b><big>'+ str(res.status_code) + " : </big>" + str(res.body) + '</b></p>'
        excep = str(res.exception)
        if excep != 'None':
            err += '<p><b>Exception: ' + excep + '</b></p>'

        traceb = html_escape(str(res.traceback))
        if traceb != 'None':
            err += "<pre>" + traceb + "</pre>"

        logSys(err)
        rv = combineKeys(xP.prefs, {
            'page':'#', 'titleName':xS('mError'), 'menuName':xS('mError'),
            'gotoMain': xS('gotoMain'),
            'errorStatus': err})
        #                ( tpl,        keyT,  menu,     keyM,   insertat)
        page = insertTPL('templateErr', rv, 'hamburger', rv, 'hamburger')
        return page


lastTime = ''
sDIR = os.getcwd()

import prefSchedule
xP = prefSchedule
from prefSchedule import getPrefs

import logSchedule
from logSchedule import logInfo, logSys

from getGeoDetails import getGeoDetails
from getSuntimes import getSuntimes

app = goBottle()

stringsJSON = "stringsPlus.json"
xStrings = json.loads(open(stringsJSON, 'r').read())

def xS(n):
    locale = str(xP.prefs['locale'])
    if not locale in ('DE', 'EN'):
        locale = 'DE'
    return xStrings[locale][n]


'''
About using "static" directory structure
https://stackoverflow.com/questions/10486224/bottle-static-files

Directory layout:
`--static
|  `--docs
|  `--icon
|  `--pict
|  `--  ... others

Example:
<img src='/static/docs/icon/minus.svg'>
'''

@app.route('/static/<filename:path>', name='static')
def serve_static(filename):
    return static_file(filename, root='static')


# onoffLabels   check stringsPlus.json for definition {'labels': {'currentName':'on,off'}
'''
   {
   "labels": {
     "WG_Innen1": "Hell,Dimmen",
     "WG_Innen2": "Hell,Dimmen",
     "Aussen": "Hell,Dimmen"
   },
'''
def getOnOffLabels(currentName):
    locale = str(xP.prefs['locale'])
    if not locale in ('DE', 'EN'):
        locale = 'DE'

    labels = xStrings[locale]['labels']      #"WG_Innen1": "Hell,Dimmen",
    if currentName in labels:
        _string = labels[currentName]
    else:
        _string = xS('on') +',' + xS('off')  # str  AN,AUS
    return _string


@app.route('/error')
def error(err):
    caller = request.fullpath[1:]
    qString = (urllib.parse.unquote(request.query_string.strip()))       #  ).replace('%20',' ')

    rv = combineKeys(xP.prefs, {
        'page': 'caller',  'titleName': xS("mError"), 'menuName': xS("mError"),
        'gotoMain': xS('gotoMain'),
        'newsDisplay': piNews['Status'],
        'newsDate': piNews['Date'],
        'news': piNews['Schedule'],
        'errorStatus': err
    })
    page = insertTPL('templateErr', rv, 'hamburger', rv, 'hamburger')
    return page


@app.route('/errtest')
def errtest():
    #abort('Boo!')
    1/0

#===========================================
bgScheduler = BackgroundScheduler()

piNews = {}
piNews['TEST'] = 'XXX'

#===========================================
def prefsSave():
    # stacker()
    jsonname = xP.prefs['jPrefs']

    try:
        #write a bak copy of current file
        shutil.copy2(jsonname, jsonname + '.bak')
    except  OSError as err:
        print('Write a prefs bak copy failed!', str(err))
        raise (err)

    # write new prefs file
    f = open(jsonname, 'w')
    f.write(json.dumps(xP.prefs, indent=2, sort_keys=True))
    f.close()

def prefsUserSave():
    # stacker()
    jsonname = xP.prefs['jPrefs']
    jsonuser = jsonname.replace(".json", ".user.json")

    try:
        #write a bak copy of current file
        shutil.copy2(jsonuser, jsonuser + '.bak')
    except  OSError as err:
        print('Write a prefs.user bak copy failed!', str(err))
        raise (err)


    userprefs = json.loads(open(jsonuser, 'r').read())
    userprefs["weekSchedule"] = xP.prefs["weekSchedule"]

    showPrefs = json.dumps(userprefs, sort_keys=True, indent=2)
    print(" --- List userprefs:\n" , showPrefs)

    # write new userprefs file
    f = open(jsonuser, 'w')
    f.write(json.dumps(userprefs, indent=2, sort_keys=True))
    f.close()



#===============================================
# calls geoDetails.TPL
@app.route('/geodetails')
def geodetails():
    global xP
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())


    #XXXXXXXXX   xP.prefs = getGeoDetails(xP.prefs)
    print("....... geoDetails set to:: ", xP.prefs['latitude'], xP.prefs['longitude'], xP.prefs['location'])

    rv = combineKeys(xP.prefs, {
        'page':caller,  'titleName': 'GeoDetails', 'menuName': 'GeoDetails',
        'gotoMain': xS('gotoMain'),
        'newsDisplay': piNews['Status'],
        'newsDate': piNews['Date'],
        'news': piNews['Schedule']
    })
    page = insertTPL('geoDetails', rv, 'hamburger', rv, 'hamburger')
    return page


#--- geoDetails.tpl calls to set xP.prefs
#    /suntimes
#    /geoCoordinates
@app.route('/suntimes')
def suntimes():
    caller = request.fullpath[1:]
    qString = (urllib.parse.unquote(request.query_string.strip())).replace('%20',' ')

    if caller == 'suntimes':
        print("/suntimes ::", qString)
        xP.prefs['sunrise'] = qString.split(';')[0].split(',')[1]
        xP.prefs['sunset'] = qString.split(';')[1].split(',')[1]

    prefsSave()

@app.route('/geoCoordinates')
def setgeo():
    caller = request.fullpath[1:]
    qString = (urllib.parse.unquote(request.query_string.strip())).replace('%20',' ')

    if caller == 'geoCoordinates':
        print("/geoCoordinates ::", qString)
        xP.prefs['latitude'] = qString.split(';')[0]
        xP.prefs['longitude'] = qString.split(';')[1]
        xP.prefs['location'] = qString.split(';')[2]    # qString.split(';')[1]

        xP.prefs['location1'] = ""
        if len(qString) > 2:
            xP.prefs['location1'] = qString.split(';')[3]

    prefsSave()

#===============================================
'''
    Tasmota device controled with
    command send from Main/Overview Page (device buttons) or direct URL call
        /set?{fName};{status}       ON or OFF for POWER Switching -- or integer for CHANNEL setting
            "/set?Stecker3;ON"      *** POWER ON/OFF Switching
            "/set?Glasdach;36"      *** CHANNEL Setting

    hamburger.tpl call:
      -- for POWER      function toggleButtonDevice
      -- for LEDstripes function changeLEDslider
'''
@app.get('/set')
def set(fnDevice="", val=""):
    global xP, monitorEvent

    if fnDevice == "":
        caller = request.fullpath[1:]       #    /set
        qString = urllib.parse.unquote(request.query_string.strip())

        _param = qString.split(";")

        if len(_param) == 2:       # ... direct/url changing value
            fnDevice = _param[0]   # Glasdach
            val = _param[1]        #  36
        else:
            return error("!!! ... switching/changing needs 2 parameters")

    _deviceDetails = deviceDetails(fnDevice)
    if 'error' in _deviceDetails:                            # TODO
        #return error(str(_deviceDetails))
        return (str(_deviceDetails))

    msg = (" /set : %s %s") % (fnDevice, str(_deviceDetails))
    logSys(msg)

    ip = xP.prefs['baseIP'] + str(_deviceDetails['ip'])
    url0 = 'http://' + ip      #  'http://' + ip + {command string}

    if val.lower() == 'on' or val.lower() == 'off':
        command = 'Power'     # process for 'POWER'  cmnd
    else:
        command = 'Channel'   #  process for 'CHANNEL' .. like with LEDstripe devices

    _channel = str(_deviceDetails['index'] +1)
    url0 += "/cm?cmnd=" + command + _channel
    url  = url0 + '%20' + str(val).strip()
    with urllib.request.urlopen(url) as response:
        response = json.loads(response.read())

        if command == 'Power':
            msg =  ("%s %s") % (fnDevice, str(response))

        if command == 'Channel':
            msg =  ("%s %s:%s") % (fnDevice, command + _channel, response[command + _channel])

        # logInfo(msg)
        #  00:51:00 set #355              -->> Glasdach {'Channel3': 40}
        #  00:26:00 set #355              -->> Glasdach {'POWER1': 'ON', 'Channel1': 1, 'POWER2': 'ON', 'Channel2': 17, 'POWER3': 'ON', 'Channel3': 20, 'Color': '032B33'}
        log2DayFile(False, msg)

        msg = (" /set : url >>%s<<") % (str(url0))
        # logSys(msg)

    # set 'changeFlag' in 'pollDevices'
    changeFlag = True
    monitorEvent.set()      # signal  to start
    return [url0, str(response)]

@app.get('/ramp')
def send2url(arg=""):          # ... Command send from BG Scheduler
    global xP

    if arg == "":                       #  Testing ramping LED device
        caller = request.fullpath[1:]   #  get  /ramp arguments
        qString = urllib.parse.unquote(request.query_string.strip())

        _param = qString.split(";")
        r = _param[1].split(",")

        # Glasdach;set,16:37,~00:01,25,00:10,60
        arg = {}
        arg['device'] = _param[0]
        arg['info'] = _param[0]
        arg['job'] = r[0]
        arg['jobSet'] = [r[0],r[1],r[2],r[3],r[4]]
        print(" /RAMP", qString, ">>" + str(arg) + "<<")

    # Check if "DayPlan was set 'inactive' on Main/Overview Page"
    if xP.prefs['dayPlanActive'] == 'false':
        mssg = " !!! DayPlan inactive -- NOT switched! " \
            + arg['device'] + " " + str(arg['info'])
        logInfo(mssg)
        logSys(mssg)
        log2DayFile(False, mssg)
        return

    logInfo(" " + str(arg))
    # {'device': 'Glasdach', 'info': 'set,16:37,~00:01,25,00:10,60', 'job': 'set', 'jobSet': ['set', ' 16:37:00', '25', '00:10', '60']}

    if 'job' in arg and arg['job'].lower() == 'set':   # go for '/set' or '/ramping'
        return set_or_ramp(arg['device'], arg['jobSet'])
        #return _returnStr
    else:
        set(arg['device'], arg['job'])                 #  (fnDevice, on/off)
    return


def deviceDetails(_device):
    '''
        Get Tasmota device details based on DeviceName or FriendlyName
        Return   array
    '''
    arg = {}
    _jDevice = _device

    if not _device in xP.jDevices:
        found = False
        for _jDevice in xP.jDevices:
            _fNames = xP.jDevices[_jDevice]['STATUS']['FriendlyName']
            if _device in _fNames:
                found = True
                break

        if found == False:
            arg['error'] = (" » Device '%s' is Inactive or Missing!") % _device
            logSys(str(arg))
            return arg

    if 'DeviceName' in xP.jDevices[_jDevice]['STATUS']:
        arg['device'] = xP.jDevices[_jDevice]['STATUS']['DeviceName']
    else:
        arg['device'] = _jDevice

    arg['ip'] = xP.jDevices[_jDevice]['ip']
    arg['module'] = xP.jDevices[_jDevice]['STATUS']['Module']
    arg['fNames'] = xP.jDevices[_jDevice]['STATUS']['FriendlyName']
    arg['index'] = arg['fNames'].index(_device)
    arg['fName'] = arg['fNames'][arg['index']]
    return arg

#===================================================

@app.route('/weekplan')
def week():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    # for selecting day file on weekplan build 'ini' file menulist
    iniFileList = iniFileMenu('weekScheduleSet')

    rv = combineKeys(xP.prefs, {
        'page':'/weekplan', 'titleName': xS("tWeekplan"), 'menuName': xS("mWeekplan"),
        'gotoMain': xS('gotoMain'),
        'schedule1': getSchedule4Day('Monday'),
        'schedule2': getSchedule4Day('Tuesday'),
        'schedule3': getSchedule4Day('Wednesday'),
        'schedule4': getSchedule4Day('Thursday'),
        'schedule5': getSchedule4Day('Friday'),
        'schedule6': getSchedule4Day('Saturday'),
        'schedule0': getSchedule4Day('Sunday'),
        'newsDisplay': piNews['Status'],
        'newsDate': piNews['Date'],
        'news': piNews['Schedule'],
        'iniFileList': iniFileList
    })
    page = insertTPL('weekplan', rv, 'hamburger', rv, 'hamburger')
    return page


def getSchedule4Day(day):
    if 'weekSchedule' in xP.prefs:
        weekSchedule = xP.prefs['weekSchedule']
        if day in weekSchedule:
            return weekSchedule[day]

    return "--"


@app.route('/weekdaySchedule')
def weekdaySchedule():
    weekSchedule = {}
    newSchedule = "--"
    currentDay = (datetime.now().strftime("%A"))

    if 'weekSchedule' in xP.prefs:
        weekSchedule = xP.prefs['weekSchedule']

        if currentDay in weekSchedule:
            newSchedule = weekSchedule[currentDay]

            try:
                open("/data/" + newSchedule, 'r')
            except:
                newSchedule = "--"

    logSys("weekday schedule is >>" + newSchedule + "<< current day is: " + currentDay)
    return newSchedule


@app.route('/updateWeekdaySchedule')
def updateWeekdaySchedule():
    caller = request.fullpath[1:]
    qString = request.query_string.strip(' ,')

    schedules = qString.split(',')
    logSys("/setWeekdaySchedule  >>" + str(schedules) + "<<")
    wDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

    for day in range(0,7):
        xP.prefs['weekSchedule'][wDays[day]] = schedules[day]
    prefsSave()
    prefsUserSave()
    week()

@app.route('/schedule')
def getSchedule():
    global xP

    caller = request.fullpath
    if caller == '/schedule':
        qString = urllib.parse.unquote(request.query_string.strip())
    else:
        qString = ""

    bgScheduler.remove_all_jobs()

    if qString == "":
        aSchedule = "Select INI "
        if 'iniFile' in xP.prefs:
            aSchedule = xP.prefs['iniFile']
            renew = True
    else:
        aSchedule = qString

    xP.switchTime = datetime.now().replace(hour=0,minute=0,second=0,microsecond=0) + timedelta(hours=24)

    xP.prefs['iniFile'] = aSchedule
    prefsSave()

    jobLines = jobsRead(aSchedule)       # jobLines
    jobs2Schedule(jobLines)

    cJob = bgScheduler.add_job(renewSchedule, 'date', run_date=str(xP.switchTime), id="renew")
    tab = scheduleActive()
    msg = " next SwitchTime  :: " + str(xP.switchTime)

    iniFileList = iniFileMenu('schedule')
    today = datetime.now().strftime("%x")
    hString = str(datetime.now())[:19]

    rv = combineKeys(xP.prefs, {
        'page':caller, 'titleName': xS('tDayplan'),'menuName': xS('mActualDay'),
        'gotoMain': xS('gotoMain'),
        'today': today,
        'newsDisplay': piNews['Status'],
        'newsDate': piNews['Date'],
        'news': piNews['Schedule'],
        'datetime': hString,
        'timeTable': tab,
        'iniFileList': iniFileList
    })
    page = insertTPL('schedulePlus', rv, 'hamburger', rv, 'hamburger')
    return page


@app.route('/removeJob')
def removeJob():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    try :
       bgScheduler.remove_job(qString)
    except:
       logInfo("Job may have been removed already")

    return


@app.route('/dayplan')
@app.route('/reload')
@app.route('/refresh')
def refreshSchedule():
    # stacker()

    global xP
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    tab = scheduleActive()
    iniFileList = iniFileMenu('schedule')

    rv = combineKeys(xP.prefs, {
        'page':'/', 'titleName': xS('tDayplan'), 'menuName': xS('mActualDay'),
        'gotoMain': xS('gotoMain'),
        'newsDisplay': piNews['Status'],
        'newsDate': piNews['Date'],
        'news': piNews['Schedule'],
        'iniFileList': iniFileList,
        'iniFile': xP.prefs['iniFile'],
        'timeTable': tab,
        'datetime': str(datetime.now())[:19]  # replace date/time string
    })
    page = insertTPL('schedulePlus', rv, 'hamburger', rv, 'hamburger')
    return page


@app.route('/edit')
def edit():
    caller = request.fullpath[1:]
    fileName = urllib.parse.unquote(request.query_string.strip())

    if fileName == "" or fileName == None:
        fileName = xP.prefs['iniFile']

    fnames = allFNames()

    rv = combineKeys(xP.prefs, {
        'page':'/', 'titleName': xS('tDayplan'), 'menuName': xS('mDayplan'),
        'gotoMain': xS('gotoMain'),
        'newsDisplay': piNews['Status'],
        'newsDate': piNews['Date'],
        'news': piNews['Schedule'],
        'datetime': str(datetime.now())[:19]  # replace date/time string
    })
    page = insertTPL('editSchedule', rv, 'hamburger', rv, 'hamburger')

    # build the html list of devices
    devices = xP.jDevices
    deviceNames = []
    deviceList = []

    for d in fnames:
        deviceNames.append(d)
        deviceList.append('<div class="menuAction menuitem changeDevice">'+d+'</div>')

    deviceNames.sort()
    #deviceList.sort()
    deviceList = ' '.join(deviceList)

    page = page.replace('&&deviceList&&', deviceList)
    page = page.replace('&&deviceNames&&', str(deviceNames))

    if fileName == 'addJob':
        page = page.replace('&&displayDef&&',"display:block")
        page = page.replace('&&JOBS&&',"")
        page = page.replace('&&FILE&&',"")
        page = page.replace('&&displaySchedule&&','display:none')

    else:
        page = page.replace('&&displayDef&&',"")
        page = page.replace('&&displaySchedule&&','display:block')

        #  newSchedule
        #if fileName == 'newSchedule':
        #    newiniFile()

        # read the selected 'ini' file, setzt   iniFileName  in prefs!
        jobLines = jobsRead(fileName, False)

        jobList = ""
        jobNo = 0
        for line in jobLines:
            jobList = jobList + '<li jobNo="' + str(jobNo) + '">' + line +'</li>'
            jobNo = jobNo +1

        page = page.replace('&&JOBS&&',jobList)

        # set the 'ini' file name
        page = page.replace('&&FILE&&',str(fileName))    #setzt fileName in Dialogfeld
    return page


@app.route('/addJob')
def addJob():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    print("--- /addJob " +  json.dumps(qString))
    jobs2Schedule ([qString])


@app.route('/fSave')
def fSave():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    qString = json.loads(qString)

    fileName = qString[0]['fileName']     #file name
    fileName = "data/" + fileName

    iniFiles =  glob.glob("data/*.ini")
    for x in iniFiles:
       if fileName == x:
           shutil.copy2(fileName, fileName + '.bak')
           #logSys(".. Make .bak Copy of >>" +fileName + "<<")

    xjobs = qString[1]['jobs'].replace('|','\n')

    f = open(fileName, 'w')
    f.write(xjobs)
    f.close()


@app.get('/fDelete')
def xDelete():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    fName = 'data/' + qString
    os.remove(fName)


@app.route('/removeJobs')
def removeJobs():
    bgScheduler.remove_all_jobs()
    return week()


@app.route('/fLoad')
def fLoad():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    fileName = qString   #[0]['fileName']     #file name
    #fileName = "data/" + fileName

    try:
        jobFile = open("data/" + fileName, 'r')
        jobs = jobFile.readlines()
        jobFile.close()
    except:
        jobs = [' * Define new Schedule', '']

        f = open("data/" + fileName, 'w')
        f.write(str(jobs))
        f.close()
        logSys("New Schedule File:" + fileName)

    logSys("Loaded :: " + str(jobs))
    return jobs


# logs system logs with 'System' or 'Info'
# or log of a weekday
@app.route('/logs')
def logList():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    if 'System' in qString  or 'Info' in qString:
        qparts = qString.split(".")
        qName = qparts[0]
        qVers = ""
        if len(qparts) == 2:  qVers = '.' + qparts[1]

        slogFile = 'logs/' + qName + '.log' + qVers
        try:
            aLines = []
            strFile = open(slogFile, 'r')
            logLines = strFile.readlines()

            for Line in logLines:
                cLine = Line.replace('[1;32m','').replace('[1;35m','').replace('[1;36m','').replace('[0m','')
                cLine = cLine.replace(chr(27),"")
                aLines.append(cLine)

        except IOError as ierr:
            msg = slogFile + " noch nicht angelegt! "
            logSys(msg + str(ierr) )
            #raise Exception(msg)
            return (msg + '<br><br>' + str(ierr))


        aLines.sort(reverse=True)
        return  ' '.join(aLines)

    elif 'Devices' in qString:
        jDev = json.dumps(xP.jDevices, indent=2)
        return  '<br>Devices<br>' + jDev

    else:    # --------------- log for a weekday

        selected =  qString.strip()
        selectedDay =  qString.strip()

        now = datetime.now()
        today = now.strftime("%A")
        if selectedDay == "":
            selectedDay = today
        fLog = logFile(selectedDay)

        output = []
        try:
            logss = open(fLog, 'r')
            output = logss.read()
            output = output.replace('\n','<br>')
        except:
           msg = " +++  " + xS("logFiles") + " "+ fLog + " " + xS("notFound")
           logSys(msg)

           output = ('<br>')  # return empty data

        if selected != "":
            return output
        else:
            rv = combineKeys(xP.prefs, {
                'page':caller,  'titleName': xS("dayList"),  'menuName': xS("dayList"),
                'gotoMain': xS('gotoMain'),
                'logList':output,
                'today':today,
                'newsDisplay': piNews['Status'],
                'newsDate': piNews['Date'],
                'news': piNews['Schedule'],
                'currentDay': xS(selectedDay),
                'thisday': selectedDay
            })
            page = insertTPL('logSchedule', rv, 'hamburger', rv, 'hamburger')
            return page
        # --- end ------------ log for a weekday


def allFNames():
    global xP
    fnames = []

    if xP.jDevices == {}:
        pass

    for d in xP.jDevices:
      _device = xP.jDevices[d]

      _channelNo = 0
      m = len(_device['STATUS']['FriendlyName'])
      for currentName in _device['STATUS']['FriendlyName']:

          _channelNo = _channelNo+1

          if currentName == 'nop':
              continue
          fnames.append(currentName)

    return fnames


@app.route('/')
def scheduleDevices():
    global xP

    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    if xP.jDevices == {}:
        err = ("../" + caller + "  No devices found! Check IPfirst/IPlast for WLAN Devices.")
        err = err + "\n Current setting: " + xP.prefs['ipfirst'] + "/" + xP.prefs['iplast']
        print(err)
        logSys(err)

        rv = combineKeys(xP.prefs, {
            'page':caller,  'titleName': xS("mError"), 'menuName': xS("mError"),
            'gotoMain': xS('gotoMain'),
            'newsDisplay': piNews['Status'],
            'newsDate': piNews['Date'],
            'news': piNews['Schedule'],
            'errorStatus': err
        })
        page = insertTPL('templateErr', rv, 'hamburger', rv, 'hamburger')
        return page

    # build html code for device
    deviceNames = []
    allDevices = []

    divBlock = \
    '<div class="itemBG"  title="IP##ip##"> \
      <span class="itemTitel">##currentName##</span> \
      <input class="toggle" \
        fName="##fName##" \
        id="##currentName##" \
        channel="##channel##" \
        module="##moduleNo##" \
        \
        type="checkbox" checked\
        onclick="toggleButtonDevice(this);"> \
    </div>'

    LEDsilder = \
    '<div class="itemBG"  title="IP##ip##"> \
      <span class="itemTitel">##currentName##</span> \
      <div class="itemSlider"> \
      <input \
        fName="##fName##" \
        id="##currentName##" \
        channel="##channel##" \
        module="##moduleNo##" \
        \
        value="##value##" \
        title="##value##" \
        \
        type="range" min="1" max="100" \
        onchange="changeLEDslider(this)"> \
      </div> \
    </div>'


    for d in xP.jDevices:
      _device = xP.jDevices[d]
      deviceNames.append(d)

      _http = str(xP.prefs['baseIP']) + str(_device['ip'])
      _ip = str(_device['ip'])
      _moduleNo = (_device['STATUS']['Module'])
      _module = _device['module']

      _channelNo = 0
      m = len(_device['STATUS']['FriendlyName'])
      for currentName in _device['STATUS']['FriendlyName']:

          _channelNo = _channelNo+1

          if currentName == 'nop':
              continue

          onoffLabels = getOnOffLabels(currentName)

          _power = 'POWER'
          if m>1: _power = _power + str(_channelNo)
          powerState = (_device['STATE'][_power])

          onoff = onoffLabels.split(',')[0]
          if powerState == "OFF": onoff =  onoffLabels.split(',')[1]

          if 'DeviceName' in _device['STATUS']:
              fName = str(_device['STATUS']['DeviceName'])
          else:
              fName = _device['STATUS']['FriendlyName'][0]

          if _moduleNo == 34:         # LEDstripe
            _Channel = 'Channel' + str(_channelNo)
            channelState = str(_device['STATE'][_Channel])

            nextelem = LEDsilder\
              .replace("##value##", channelState)\

          elif _moduleNo == 29:     #  'module': {'29': 'Sonoff T1 2CH'}
            _power = 'POWER' + str(_channelNo)
            channelPower = str(_device['STATE'][_power])

            nextelem = divBlock\
              .replace("##onoff##", onoff)\
              .replace("##channelPower##", channelPower)\

          else:
              #if 'active' in _device and (str(_device['active']) == '1'):
              #disabled = ''

              nextelem = divBlock\
                  .replace("##onoff##", onoff)\

          cstate = 'checked'
          disabled = 'disabled'
          muted = 'none'
          #if 'muted' in _device and (str(_dev['muted']) == 'block'):
          #    disabled = 'disabled'
          #    muted = 'block'

          nextelem = nextelem\
              .replace("##currentName##", currentName)\
              .replace("##fName##", fName)\
              .replace("##title##", 'device.' + _ip)\
              .replace("##http##", _http)\
              .replace("##ip##", _ip)\
              .replace("##moduleNo##", str(_moduleNo))\
              \
              .replace("##channel##", str(_channelNo))\
              .replace("##labels##", powerState)\
              .replace("##onoffLabels##", onoffLabels)\

          allDevices.append(nextelem)

          #print("#  ... Device: ", _moduleNo, _module, currentName, fName, _ip,  _channelNo, powerState)
    #  <<<end  'for currentName'

    # get first device (alphabetic order)
    deviceNames.sort()
    firstDevice = deviceNames[0]

    # Sorted based on the generated HTML code, the 'title'=ip is the sort criteria
    allDevices.sort()
    allDevices = ' '.join(allDevices)
    logSys(" :: devices sorted by name :: <br>" + '<br>'.join(deviceNames))

    rv = combineKeys(xP.prefs, {
        'page':caller,  'titleName': xS("tOverview"), 'menuName': xS("mOverview"),
        'gotoMain': xS('gotoMain'),
        'newsDisplay': piNews['Status'],
        'newsDate': piNews['Date'],
        'news': piNews['Schedule'],
        'allDevices': allDevices
    })
    page = insertTPL('scheduleDevices', rv, 'hamburger', rv, 'hamburger')
    return page


def iniFileMenu(modus):    # build 'ini' file menu
    fileList = ""
    fHtml = '<div class="menuItem" href="/' + modus + '?_fName_">_fName_</div>'

    iniFiles =  sorted(glob.glob("data/*.ini"))

    for x in iniFiles:
        x = x.replace('data/','')
        fileList += fHtml.replace('_fName_',x)

    return fileList


#======================================================


# following calls will set a specific prefs item and
#   return updated /schedule page
#@app.route('/news')
@app.route('/iniFile')
@app.route('/locale')
@app.route('/dayPlanActive')
def setPrefs():
    caller = request.fullpath[1:]
    qString = (urllib.parse.unquote(request.query_string.strip())).replace('%20',' ')

    if caller in xP.prefs:
        if caller == 'locale':
            if not qString in ('DE', 'EN'):
                qString = 'DE'

        xP.prefs[caller] = qString
        prefsSave()

        return (xP.prefs)
    else:
        return ("** Unknown item in xP.prefs! **")



@app.route('/prefs')
def listPrefs():
    global xP

    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    if qString != "":
        q = qString.split("=")

        if 1 == len(q):
            xP.prefs[q[0]] = ""
        else:
            xP.prefs[q[0]] = q[1]

    showPrefs = json.dumps(xP.prefs, sort_keys=True, indent=2)
    showSonoffs = json.dumps(xP.jDevices, sort_keys=True, indent=2)

    showPrefs = (showPrefs + "<br><br>" + showSonoffs).replace("\n","<br />").replace("  ","&nbsp;&nbsp;")
    showPrefs = "<p style='font-family:monospace'>" + showPrefs + "</p>"

    return [showPrefs]


#@app.route('/newsDate')
def setNewsDate():
    caller = request.fullpath[1:]
    message = urllib.parse.unquote(request.query_string.strip())
    logInfo("/" + caller + "  >>" + str(message) + "<<")

    xP.prefs['newsDate'] = str(datetime.now())[:10]


#=================================================
@app.route('/about')
def about():
    caller = request.fullpath[1:]
    message = urllib.parse.unquote(request.query_string.strip())

    locale = str(xP.prefs['locale'])
    if not locale in ('DE', 'EN'):
        locale = 'DE'

    xP.prefs['platform'] = platform.uname()[1] + " -- " + str(platform.platform()).replace("'","")

    logSys("/" + caller + "  >>" + str(platform.uname()) + "<<  >>" + locale + "<<")
    if locale == 'EN':
        deDisplay = 'none'
        enDisplay = 'block'

    if locale == 'DE':
        deDisplay = 'block'
        enDisplay = 'none'

    today = datetime.now().strftime("%x")
    rv = combineKeys(xP.prefs, {
        'page':'/about', 'titleName': (xS("mAbout") + " schedulePlus"), 'menuName': (xS("mAbout") + " schedulePlus"),
        'gotoMain': xS('gotoMain'),
        'deDisplay': deDisplay,
        'enDisplay': enDisplay,
        'today': today,
        'newsDisplay': piNews['Status'],
        'newsDate': piNews['Date'],
        'news': piNews['Schedule']
    })
    page = insertTPL('aboutSchedule', rv, 'hamburger', rv, 'hamburger')
    return page


#-------------------------------------------
@app.route('/close')
def close():
    global schedulePlusStatus

    schedulePlusStatus = False
    time.sleep(8)

    caller = request.fullpath[1:]
    message = urllib.parse.unquote(request.query_string.strip())
    logInfo(caller)

    os.kill(os.getpid(), signal.SIGTERM)


#===========================================
def combineKeys(rv1, rv2):
    return {**rv1, **rv2}

def templateSetup(templ, rv):
    locale = str(xP.prefs['locale'])
    if not locale in ('DE', 'EN'):
        locale = 'DE'

    keys = combineKeys(rv, xStrings[locale])

    thisTemplate = template(templ, keys)

    # special formatting character replacement
    return thisTemplate.replace("{P}","<br>").replace("{i}","<i>").replace("{/i}","</i>")

# Support to insert a sub-page.tpl (like 'menu') into
# a main.tpl (like 'tpl') at a key {{hamburger}}.
# Both templates can use their own keys.
def insertTPL(tpl, keyT, menu, keyM, insertAt):
    subtpl = templateSetup(menu, keyM)
    rv = combineKeys(keyT, {insertAt:subtpl})

    temp = templateSetup(tpl, rv)
    return temp


#=============================================
def xgetNews():
# ---------------------------
    global piNews

    piNews['Status'] = "display:none"

    mdName = 'static/docs/newsplus.html'
    mdFile = open(mdName, 'r')
    mdLines = mdFile.read()

    piNews['Schedule'] = mdLines

    # Date of the actual News is set with ::  <h3><!--date-->2020-01-06
    x = mdLines.find("<h3><!--date-->") +15  #The date string starts after charPos 15
    piNews['Date'] = mdLines[x:x+10]

    logInfo("News :: " + str(piNews['Date']))

#=============================================

def jobsRead(fileName = 'newSchedule.ini', iniName = True):
#---------------------------------------
    # logSys("jobsRead :: " + str(fileName))

    if fileName == "" or fileName == None:
        fileName = 'newSchedule.ini'

    if fileName[0:5] == "data/":
        fileName = fileName[5:]

    try:
        jobFile = open("data/" + fileName, 'r')
        jobs = jobFile.readlines()
        jobFile.close()

    except:
        jobs = [' * Define new Schedule', '']

        f = open("data/" + fileName, 'w')
        f.write(str(jobs))
        f.close()
        logSys("New Schedule File:" + fileName)

    if iniName == True:
        xP.prefs['iniFile'] = fileName

    msg = "INI File " + fileName
    logSys(msg  + " type:" + str(type(jobs)) + "\n" + str(jobs))
    logInfo(msg)

    return jobs

'''
def newiniFile(fileName = 'newSchedule.ini'):
#---------------------------------------
    logSys(" :: New Schedule File:" + str(fileName))   #DEV

    f = open("data/" + fileName, 'w')
    f.write(' * New Schedule')
    f.close()
'''


def jobs2Schedule(jobLines):
#---------------------------------
# Resolve jobLines to generate single scheduleJobs
    '''
    lampe2; on
    lampe2; on,22:50;off,+:10
    lampe2; on,+:02;  off,+:03:00
      * text/comment
    lampe2; on,+:02;off,+:03:00
    lampe2; on,+01:02,sunrise;off,-01:30,sunset;on,~:10,18:00;off,~:15,21:05

    LEDstripe; set,12:00,50           set at 'time' to 'value'
    LEDstripe; set,12:00,50,60,00:10  set at 'time' from 'value1' to 'value2' in 'timedelta'

            # 1 Stecker3 on,19:35             |
            # 1 Stecker3 on,sunrise           |--  ON/OFF  1 .. 2  timing param
            # 2 Stecker3 off,sunset,+0:10     |

            #                                ______ SET    2 .. 5  param  for timimg and LEDvalue
            # 2 Glasdach set,21:00,22                  set      um '21:00'  auf '22'
            # 3 Glasdach set,sunset,~00:10,33          set      um 'sunset' +rndm '00:10'min auf '33'
            # 4 Glasdach set,21:02,44,00:20,55         Ramping  um '21:02'  von '44' über '00:20'min bis '55'
            # 5 Glasdach set,sunset,~00:12,22,00:15,44 Ramping  um 'sunset' +rndm '00:12'min von '22' über '00:15'min bis '44'

     lampe2; on,+:02                  .... switching ON/OFF
            currentDevice= lampe2;
            currentJob= on,+:02
    '''

    global xP, lastTime

    for cJobs in jobLines:
        cJobs = cJobs.strip()

        # strip out empty or comment lines
        if len(cJobs) == 0 or cJobs[0] == '*':
            continue

        cJob = cJobs.split(";")       # multiple 'job's on one line, separated with semikolon
        cJobLen = len(cJob)
        currentDevice = cJob[0].strip()

        if lastTime == '':
            lastTime = datetime.now()

        n = 1
        while n < (cJobLen):
            currentJob = cJob[n].strip().replace(" ", "")   # delete any space from .ini string

            # inkrement now to ensure to have a 1 sec delta to the previous switchtime     #TODO  ?? +1sec
            # now =  now + timedelta(hours=0, minutes=0, seconds=n)
            lastTime, jobDefinition, xP.switchTime = scheduleSet(lastTime, currentDevice, currentJob, xP.switchTime)

            n += 1
    return


def scheduleSet (onTime, currentDevice, currentJob, switchTime):
#---------------------------------
# Process currentJob to generate APSchedule task
    _currentJob = currentJob.lower().strip().split(",")
    jobLen = len(_currentJob)
    jobTyp = _currentJob[0].lower()

    logInfo(str(currentDevice) + " " + str(_currentJob))
    #  HausEingang ['off', '23:45', '~00:10']
    #  Glasdach ['set', '17:50', '~00:10', '25', '00:10', '60']

    if (jobTyp == 'on' or jobTyp == 'off' or jobTyp == 'set'):

        # direct ON/OFFswitching
        if (jobTyp == 'on' or jobTyp == 'off') and jobLen == 1:
            arg = {}
            arg['device'] = currentDevice
            arg['job'] = jobTyp
            send2url(arg)
            jmsg = [str(onTime)[0:19], currentDevice, currentJob]
            return [onTime, jmsg, switchTime]

        if jobLen < 2:
            logSys("Job definition needs more arguments " + "::" + str(currentJob) + " : " + str(switchTime))
            error("# Job has to be: on/off/set")
            jmsg = [str(onTime)[0:19], currentDevice, currentJob]
            return [onTime, jmsg, switchTime]

        else:  # handle base and random time
            if ((_currentJob[1].find(':') > -1) or _currentJob[1][0] == 's')==False:    # need time or sunset/sunrise
                logSys("Job definition needs switchtime " + "::" + str(currentJob) + " : " + str(switchTime))
                error("# Job definition needs switchtime")
                jmsg = [str(onTime)[0:19], currentDevice, currentJob]
                return [onTime, jmsg, switchTime]

            else:  # get time .. and with random shift time

                if (_currentJob[1][0] == '+'):
                    h, min, sec = parseTime (_currentJob[1][1:])
                    pTime = (timedelta(hours=h, minutes=min, seconds=sec))
                    #pTime = baseTime(_currentJob[1][1:])
                    xTime = onTime + pTime
                else:
                    xTime = baseTime(_currentJob[1])

                _randomTime = '00:00'

                jobSet = _currentJob
                jobSet[0] = jobTyp

                if jobLen > 2:    # check next argument  randomTime or value/Integer
                    if (_currentJob[2].find(':') > -1):
                        _randomTime =  randomTime(_currentJob[2])

                        xTime = xTime + _randomTime
                        jobSet[1] = str(xTime)[10:19]
                        jobSet.pop(2)   # remove random argument
        # <<--- handle base and random time

        wasOnTime = onTime     # remember 'on' time for 'off' table entry
        onTime = xTime
        jmsg = []

        # check if xTime is before actual time
        msg = str(xTime)[10:19] + " " + currentDevice + " [" + currentJob + "] "  \
            + "( ~" + str(_randomTime) + ")"
        if (xTime < datetime.now()):
            logInfo(" →Skip: " + msg + "   +++ " + xS("beforeTime"))
        else:
            logInfo(" →Set: " + msg)
            # →Set:  13:09:00 Glasdach [set,13:07,+00:02,20,00::30,5] ( ~0:02:00)

            jmsg = [str(xTime)[0:19], currentDevice, currentJob]
            jobName = str(int(time.time() * 1000))[6:]

            info =  _currentJob
            if 'off' in _currentJob:
                info.append("on: " + str(wasOnTime)[11:16])

            # pass to the Background Scheduler
            cJob = (bgScheduler.add_job(send2url, 'date', run_date=str(xTime), \
                args=[{'device':currentDevice, 'info':currentJob, 'job':jobTyp, 'jobSet':jobSet}], \
                id=jobName))

            if xTime > switchTime:      # if 'current device switch time' is later than 'previous switch time'
                switchTime = xTime + timedelta(hours=0, minutes=0, seconds=5) # inkre so NEW is last 'job'

    else:
        logSys(xS("noState") + "::" + str(currentJob) + " : " + str(switchTime))  #  no on/off
        error(xS("noState"))  # ERROR: has to be: on/off/set

        jmsg = [str(onTime)[0:19], currentDevice, currentJob]

    #print("____switchTime" + "::" + str(currentJob) + " :: " + str(xTime) + " :: " + str(switchTime))  #
    return [onTime, jmsg, switchTime]

# ----------------------

def baseTime(swTime):
    if swTime == 'sunrise':
        xTime = parse(xP.prefs['sunrise'])
    elif swTime == 'sunset':
        xTime = parse(xP.prefs['sunset'])
    else:
        xTime = parse(swTime)
    return xTime

def randomTime(rndTime):
# '+' add or '-' subtract time value
# '~' add or '~-' subtract 'random' time value
    h = 0
    min = 0
    sec = 0
    random_subtract = False

    if rndTime[0:2] == "~-":  #  subtract random time
        random_subtract = True
        delta = rndTime[2:]   #  ~-
    else:
        delta = rndTime[1:]   #  ~    add random time

    if rndTime[0:2] == "~+":  #  ~+   add random time
        delta = rndTime[2:]

    h, min, sec = parseTime (delta)
    deltaTime = timedelta(hours=h, minutes=min, seconds=sec)

    if rndTime[0] == '+':   #  add deltaTime
        pass

    if rndTime[0] == '-':   #  substract deltaTime
        deltaTime = -deltaTime

    elif rndTime[0] == '~': #  add random minutes
        rMin = h * 60 + min
        if random_subtract:
            deltaTime = -timedelta(minutes=random.randrange(rMin))
        else:
            deltaTime = timedelta(minutes=random.randrange(rMin))

    return deltaTime

def parseTime (tStr):
    xSt = tStr.split(":")
    sln = len(xSt)
    h=0; min=0; sec=0
    if sln >= 1:
        h=0     if xSt[0] == '' else int(xSt[0])
    if sln >= 2:
        min=0     if xSt[1] == '' else int(xSt[1])
    if sln == 3:
        sec=0  if xSt[2] == '' else int(xSt[2])
    return h, min, sec

# .......................

# set or ramping in background
def set_or_ramp(device, cmnd):
    val = cmnd[2]
    setReturn = set(device, val)             #  set with first argument
                                             #  get back url for further use
    msg =("\n ??? 'set or ramping' return " + str(setReturn) + "\n")
    logSys(msg)
    #>>> setReturn = ['http://192.168.178.59/cm?cmnd=Channel2', "{'POWER1': 'ON', 'Channel1': 1, 'POWER2': 'ON', 'Channel2': 1, 'POWER3': 'ON', 'Channel3': 2, 'Color': '030305'}"]
    #
    #>>> setReturn[0]   'http://192.168.178.59/cm?cmnd=Channel2'
    #>>> setReturn[1]    "{'POWER1': 'ON', 'Channel1': 1, 'POWER2': 'ON', 'Channel2': 1, 'POWER3': 'ON', 'Channel3': 2, 'Color': '030305'}"


    #??? set return  http://192.168.178.59/cm?cmnd=Channel3%20
    #??? set return  {'error': " » Device 'Glasdach' is Inactive or Missing!"}
    if 'error' in setReturn:
        return setReturn            ####TODO


    if setReturn != "" and len(cmnd) > 3:    #  Ramping for device
        #
        # !!!  Ramping for  Glasdach ['set', '16:37', '25', '00:10', '60']

        h, min, sec = parseTime (cmnd[1])
        startTime = datetime.now().replace(hour=h,minute=min,second=sec,microsecond=0)

        url0 = setReturn[0]
        channel = url0.split("=")[1]

        # if startVal was not passed ( as '') use current 'device/channel' setting
        if cmnd[2] == '':
            #  setReturn = ['http://192.168.178.59/cm?cmnd=Channel3', "{'Channel3': 9}"]

            y= json.loads(setReturn[1].replace("'",'"'))
            cmnd[2] = y[url0.split("=")[1]]

        startval = int(cmnd[2])
        steps = (int(cmnd[4]) - int(cmnd[2]))
        h, min, sec = parseTime (cmnd[3])
        inkrTime = abs((timedelta(hours=h, minutes=min, seconds=sec)).total_seconds()/steps)

        rmp = Thread(target=ramp, args=(device, startTime, inkrTime, startval, steps, url0, channel), daemon = True)
        rmp.start()
    return setReturn


#   →Set:  13:09:00 Glasdach [set,13:07,+00:02,20,00::30,5] ( ~0:02:00)

rampDevs = {}
def ramp(device, startTime, inkrTime, cVal, steps, url0, channel):
    global rampDevs

    if device in rampDevs:
        msg = (str(datetime.now())[11:] + " !!! ramp has already device: " + device)
        logSys(msg)
        rampDevs[device] = 999     #???? TODO   this will terminate both !!!
        return

    msg = "startTime:" + str(startTime) \
      + ", inkrTime:"  + str(inkrTime) \
      + ", startVal:" + str(cVal) \
      + ", steps:" + str(steps)
    #  ... ramp :args: , startTime:2022-03-08 13:09:00, inkrTime:2.0, cVal:20, steps:-15
    logSys(" ... ramp :args: " + msg)

    startVal = cVal
    rampMonitor = Event()
    iStep = 1
    if steps < 0: iStep = -1
    rampDevs[device] = -1

    while rampDevs[device] < (abs(steps)):       #  while not rampMonitor.is_set():
        rampDevs[device] = rampDevs[device] + 1

        #! url  = url0 + '%20' + str(rampDevs[device])
        url  = url0 + '%20' + str(cVal).strip()
        with urllib.request.urlopen(url) as response:
            response = json.loads(response.read())
            msg =  (" →→→ ramp :2: %s %s") % (device, str(response))
            # print(msg)

        cVal = cVal + iStep

        rampMonitor.wait(inkrTime)

    msg = ("%s %s:  %s -- (%s, %s|%s, %s) ") % \
        (str(device), channel, str(startTime)[11:19], str(startVal), steps, str("{:0.4f}".format(inkrTime)), str(cVal - iStep))

    log2DayFile(False, msg)
    logSys(msg)
    rampDevs.pop(device)

    return

# ----------------------------
@app.route('/thread')
def thread():
    for t in threading.enumerate():
    	print("  thread ", t.getName())
# ----------------------------


def scheduleActive():
#---------------------------------
    output = []

    button = ("<div id='removeJob' onclick='removeTr(this)' \
         job='_job_' title='" + xS('removeJob') + "'> \
        <img src='/static/docs/icon/entry-delete.svg'>  \
        </div>")

    sON = xS("on")    #'AN'
    sOFF = xS("off")  #'AUS'

    aJobs = len(bgScheduler.get_jobs())

    if aJobs > 0:
        n = 0
        cDay = datetime.now().day
        while n < aJobs:
            schTime = str(bgScheduler.get_jobs()[n].trigger).replace("date", '')
            sTime = (bgScheduler.get_jobs()[n].trigger).run_date

            schTime = s2(sTime.hour) + ":" + s2(sTime.minute) + ":" + s2(sTime.second)

            if sTime.day != cDay:        # mark time if next day
                schTime = '> ' + schTime

            if (bgScheduler.get_jobs()[n].name) == 'send2url':
                info = str(bgScheduler.get_jobs()[n].args[0]['info'])
                mArgs = (bgScheduler.get_jobs()[n].args[0])
            else:
                info = bgScheduler.get_jobs()[n].name


            if (bgScheduler.get_jobs()[n].id) == 'renew':
                button = ""
                _device = ""
                _job = "NEW"
                _jobSet = ""
                _info = "***  Lade Job Daten neu! ***"
            else:
                _device = mArgs['device']
                _jobSet = str(mArgs['jobSet'])
                _info = mArgs['info']

                if ('off,' in _info) == True:
                    _info = _info + " / " + str(mArgs['jobSet'][2])
                _job = mArgs['job'].lower()
                _job = xS(_job)


            _jobid = str(bgScheduler.get_jobs()[n].id)
            button1 = button
            button1 = button1.replace('_job_', _jobid)

            newAppend = ("<tr>" \
                     "<td>" + schTime   + "</td>" \
                     "<td>" + _device  + "</td>" \
                     "<td>" + _job + "</td>" \
                     "<td>" + _info + "</td>" \
                     "<td>" + button1 + "</td></tr> ")

            output.append(newAppend)
            n += 1

        output.sort()

    return (' '.join(output))


# reads jobs back from Scheduler (bgScheduler) to update
#  the current job list
def renewSchedule():
        #if 'iniFile' in xP.prefs:
        daySchedule = weekdaySchedule()

        if 'iniFile' not in xP.prefs:
            xP.prefs['iniFile'] = 'newDaySchedule.ini'

        if daySchedule != "--":
            xP.prefs['iniFile'] = daySchedule

        aSchedule = xP.prefs['iniFile']

        bgScheduler.remove_all_jobs()

        xP.switchTime = datetime.now().replace(hour=0,minute=0,second=0,microsecond=0)+  timedelta(hours=24)

        xP.prefs = getSuntimes(xP.prefs)
        prefsSave()

        jobLines = jobsRead(aSchedule)
        jobs2Schedule(jobLines)

        tab = scheduleActive()
        cJob = bgScheduler.add_job(renewSchedule, 'date', run_date=str(xP.switchTime), id="renew")
        msg = "Renew Schedule '" + aSchedule + "'  Next Switch Time: " + str(xP.switchTime)[:19] + " lang:" + str(xP.prefs['locale'])
        logSys(msg)
        log2DayFile(True, msg)
        #---- prefsSave()
        #else:
        #msg = "ERROR 'renewSchedule'"
        #logSys(msg)
        #raise Exception (msg)

#================================================
def s2(v):
    if v < 10:
        return '0'+str(v)
    return str(v)


def log2DayFile(new=False, info=""):
    sDay = datetime.now()
    logF = logFile(sDay.strftime("%A"))

    if new == True:
        logInfo("new log day file: " + logF + " " + datetime.now().strftime("%Y-%m-%d"))
        try:
            os.remove(logF)
        except:
            pass

    now = datetime.now()
    f = open(logF, 'a')

    f.write(str(now)[0:19] + " : " + info + "\n")
    f.close()


def logFile(sDay):
    return 'logs/' + sDay + '.log'
#=============================================

@app.route('/docs')
def openDocs():
    caller = request.fullpath[1:]
    qString = urllib.parse.unquote(request.query_string.strip())

    return serve_static_file(qString)

@route('/filesPath/<staticFile>')
def serve_static_file(staticFile):
    filePath = 'static/docs/'
    return static_file(staticFile, root=filePath)


#=============================================

def pingRouter():
    p = subprocess.Popen(['ping',str(xP.prefs['routerIP']),'-c','1',"-W","2"])
    p.wait()
    ps = p.poll()
    if ps == 0: router =  "Router Status : OK  "
    if ps != 0: router =  "Router Status : UNREACHABLE  "
    return router

# --------------------------------------
schedulePlusStatus = True
changeFlag = False
monitorEvent = Event()   #  For direct terminating the loop

def schedulePlusMonitor(n):
    global xP, schedulePlusStatus, monitorEvent, changeFlag, ledLoop

    routerStatus = pingRouter()

    log0 = ("schedulePlusMonitor started! " + routerStatus)
    logSys(log0)

    while schedulePlusStatus:
        monitorEvent = Event()
        while not monitorEvent.is_set():
            xP.jDevices, inactiveIPs = getDevices(xP.prefs['ipfirst'],xP.prefs['iplast'])

            msg =str(datetime.now())[:22] + " *** schedulePlusMonitor " + str(changeFlag) + " inactiveIPs ::" + str(inactiveIPs)
            #print(msg)

            changeFlag = True
            monitorEvent.wait(10)


@app.route('/pollDevices')        # poll actual device list as read with sonoffDevices.py
def pollDevices():                # called from 'scheduleDevices.tpl' xhr.open('GET', '/pollDevices');
    global xP, changeFlag

    if changeFlag == True:
        changeFlag = False
        return json.dumps(xP.jDevices, indent=4)


#===========================================
def main():
    global xP, schedulePlusStatus

    msg = str(datetime.now())[:19] + ' _________ Started schedulePlus (main) ________   (' + cVersion + ') '

    logSys(msg)
    logInfo(msg)

    debug(mode=False)        # Bottle debug mode <<<<<<<<<<<<<<<<<


    xP.switchTime = datetime.now().replace(hour=0,minute=0,second=0,microsecond=0)+  timedelta(hours=24)
    xP.prefs = getPrefs()               # setup prefs from   JSON files
    xP.prefs = getGeoDetails(xP.prefs)  # get latitude, longitude, location etc
    if 'location1' not in xP.prefs:
        xP.prefs['location1'] = xP.prefs['location']

    xP.prefs = getSuntimes(xP.prefs)    # get sunrise, sunset

    print("#  ... MAIN prefs ::", json.dumps(xP.prefs, indent=2, sort_keys = True))
    prefsSave()

    xgetNews()

    xP.jDevices, failedIPs = getDevices(xP.prefs['ipfirst'],xP.prefs['iplast'])

    logSys("bgScheduler.start")
    bgScheduler.start()    # start the scheduler

    i = 0
    t = Thread(target=schedulePlusMonitor, args=(i,), daemon = True)
    t.start()

    logSys("renewSchedule")
    renewSchedule()  # if iniFile is set, load jobList of it

    #try:
    # starting bottle with web page
    msg = ("\n%s#  ... schedulePlus Server started! Supporting Devices '%s .. %s' *** %s" % (ba, xP.prefs['ipfirst'], xP.prefs['iplast'], e0 ))
    activeDevices, passivDevices = ipDevices(xP.prefs['ipfirst'], xP.prefs['iplast'])
    msg1 = ("\n%s#  ... IPs active :: %s\n%s#  ... IPs failed :: %s %s" % (bb, str(activeDevices), br, str(passivDevices), e0))

    logSys(msg + msg1)

    app.run(host = xP.prefs['server'], port = xP.prefs['port'], reloader=False)
    logSys(" *** schedulePlus done!")


#----- TEST  Power on routine ----------------------------------

def pingFB():
    global xP

    p = subprocess.Popen(['ping',xP.prefs['routerIP'],'-c','1',"-W","2"])
    p.wait()
    ps = p.poll()
    if ps == 0: router =  "Router Status : OK  "
    if ps != 0: router =  "Router Status : UNREACHABLE  "
    return router

def pingLog(msg):
    #f = open('/home/pi/schedulePlus/ping.log', 'a')
    f = open('ping.log', 'a')
    f.write(msg + "\n")
    f.close()


def XXmain():
    global xP
    xP.prefs = getPrefs()
    msg = "\n ----------- " + str(datetime.now())[:24] + " -----------\n   PING restart / Router from prefs :: " + xP.prefs['routerName'] + " " + xP.prefs['routerIP']
    print (msg)
    pingLog(msg)

    pingStatus = True
    while pingStatus:
        pingSet = Event()               # loop for pings
        while not pingSet.is_set():
            msg = (str(datetime.now())[:24] + "#  *** pingStatus  ... " + pingFB())

            print(msg)
            pingLog(msg)
            pingSet.wait(10)

#-------------------------------------------
if __name__ == '__main__':
    rcode = main()
