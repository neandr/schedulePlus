#!/bin/bash

cat $1 | sha256sum | head -c 64 > $1.sha
