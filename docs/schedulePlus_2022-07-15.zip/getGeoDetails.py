#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
    Copyright (C) 2015 - 2022 gWahl
"""
#  **schedule+**     getGeoDetails.py         /cVersion/2022-04-26/

import urllib.request
import json

IP_BASE_URL = "http://ipinfo.io/json"

PREFS = 'data/jPrefs.json'

def getGeoDetails(xp):

    if not 'latitude' in xp:
        with urllib.request.urlopen(IP_BASE_URL) as response:
            rv = json.loads(response.read())

        if (type(rv) is dict):
            xp["longitude"] = (rv["loc"].split(",")[1])[0:7]
            xp["latitude"] = (rv["loc"].split(",")[0])[0:7]

            xp["location"] = str(rv["city"])   #str(rv['city'].encode('utf-8'))
            xp["locale"] = str(rv["country"])
            xp["status"] = response.getcode()
        else:
            xp["status"] = " --- geoDetails (ip) failed to deliver geocoordinates for %s" % (response.getcode())

    if not 'location1' in xp:
        xp["location1"] = ""

    return xp

#---------------------------------
if __name__ == "__main__":

    with open(PREFS) as data_file:
      xprefs = json.load(data_file)

    rv = getGeoDetails({})

    if rv['status'] == 200:
      xprefs['longitude'] = rv ['longitude']
      xprefs['latitude'] = rv ['latitude']
      xprefs['location'] = rv ['location']
      xprefs['locale'] = rv ['locale']

      # update prefs file
      f = open(PREFS, 'w')
      f.write(json.dumps(xprefs, indent=2, sort_keys=True))
      f.close()

      print (" xprefs  to file    :",json.dumps(xprefs, indent=2, sort_keys=True))
