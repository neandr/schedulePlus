#! /bin/sh
date
sudo service schedulePlus start
sudo service schedulePlus status
