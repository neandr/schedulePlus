#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
    Copyright (C) 2015 - 2021 gWahl
'''
#   /cVersion/2020-11-03_00/

import socket, subprocess, sys, json

def getIPbase():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ipBase = s.getsockname()[0]
    s.close()

    print(" ...  systemAndPort   getIPbase : ", ipBase)


    result = (socket.gethostbyaddr(ipBase))

    print(" ...  systemAndPort   getIPbase : ", ipBase, result)

    return ipBase

if __name__ == '__main__':
    ipBase = getIPbase()
    result = (socket.gethostbyaddr(ipBase))

    name = result[0].split('.')[0]

    xprefs= {}
    port = ""

    with open('data/jPrefs.json') as data_file:
       xprefs = json.load(data_file)
    port = xprefs['port']
    ipPort = str(ipBase) + ":" + str(port)
    namePort = str(name) + ":" + str(port)

    sys.exit ([namePort, ipPort])
