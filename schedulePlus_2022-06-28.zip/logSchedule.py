#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
    Copyright (C) 2015 -2021 gWahl
'''
#  /cVersion/2021-02-25_13/

import prefSchedule
xP = prefSchedule

import logging, traceback, os, signal
import logging.handlers

from functools import wraps
from datetime import datetime

from bottle import request, response
import sys


logInfoName = "logs/Info.log"
logSysName =  "logs/System.log"

# preformat string and include date/time for sorting the listing
formatter =  logging.Formatter("<pre %(asctime)s>%(message)s</pre>","%Y-%m-%d %H:%M:%S")


#formatter =  logging.Formatter("## %(asctime)s -- %(message)s","%H:%M:%S")

fh = logging.handlers.RotatingFileHandler(
              logSysName, maxBytes=50000, backupCount=2)
fh.setFormatter(formatter)

#----------------
# Logger for System Messages goes to piSystem.log
def logSys(msg, color='35'):   # magenta
    print("### logSys  :: ", msg)
    loggerS.info(logString(msg, color, True))

loggerS = logging.getLogger('cSys')
loggerS.setLevel(logging.INFO)  # normal setting at which level logging starts

fh = logging.handlers.RotatingFileHandler(
        logSysName, maxBytes=50000, backupCount=2)
fh.setFormatter(formatter)
loggerS.addHandler(fh)


#----------------
# Logger for Info Messages
def logInfo(msg, color='32'):   # green
    print("### logInfo :: ", msg)
    loggerI.info(logString(msg, color, False))

loggerI = logging.getLogger('cInfo')
loggerI.setLevel(logging.INFO)  # normal setting at which level logging starts

fh = logging.handlers.RotatingFileHandler(
        logInfoName, maxBytes=50000, backupCount=2)
fh.setFormatter(formatter)
loggerI.addHandler(fh)


#----------------
def logString(msg, color, source):
    stack = traceback.extract_stack()
    filename, codeline, funcName, text = stack[-3]
    filename1, codeline1, funcName1, text1 = stack[-4]

    head, tail = os.path.split(filename)
    root, ext = os.path.splitext(tail)

    if funcName == "_logBottle":
        funcName = "bottle"

    if source == True:
        s = " " + funcName1 + " #" + str(codeline1) + " --> " \
          + funcName  + " #" + str(codeline)
        s1 = "{:42}".format(s)
    else:
        s = (" " + funcName + " #" + str(codeline)).ljust(22," ")
        s1 = "{:20}".format(s)

    d = str(datetime.now())[11:19]
    return (d + s1 + " -->> " + msg.replace('\n',''))

    #d = str(datetime.now())[11:19]
    #return (s + " " + msg.replace('\n',''))



def main():
    pass
