


	var _newsWindow = null;


	var docs = {

	// ***** Customize links for individual use ***********

		forum:    "https://groups.google.com/forum/#!forum/pischedule7",
		DBox:     "https://neandr.github.io/piSchedule/",

		Overview: "scheduleOverview.html",
		//timeline: "timeline.html",
		Edit:     "scheduleEdit.html",
		Examples: "scheduleExamples.html",
		Features: "scheduleFeatures.html",

	// ***** Customize links for individual use ***********



	// ***** DO NOT  change lines below ****

		detail : null,
		page : null,
		lastInfo : "",

		// open a new window to show a docu page, if the page isn't defined
		// open the main docu page with a bookmark
		open : function(name) {
			this.link = this.DBox + language.toLowerCase() +'.';

			if (this.page != null) {this.page.close()}
			switch (name) {
				case 'Overview':
				case 'Edit':
				//case 'timeline':
				case 'Examples':
				case 'Features':
					this.page = window.open(this.link + docs[name], 'docu');break;

				default:
					this.page = window.open(this.link + this.Overview + "#" + name, 'docu');break;
			}
		},

		// open a modal window to show main docu page with a bookmark;
		// modal window has two icons to
		//   -- reposition the docu at the bookmark
		//   -- open the docu on a separte window
		set :  function (xThis, detail, language) {
			var info = xThis.id;
			this.detail = detail;
			this.link = this.DBox + language.toLowerCase() + ".";

		console.log(" *** schedulePlus pi.docs.js  info: " + info, detail, language);

			switch (info) {

				case 'callForum':
					if (_newsWindow != null) {
						_newsWindow.close();
					}
					_newsWindow = window.open(this.forum,"forum");
				break;

				case 'doRepeat':
					var doc = this.link + this.detail + "#" + this.lastInfo;
		console.log(" *** piSchedule - pi.docs.set     doRepeat: " + "  doc:: " + doc)

					$('#frameHelp')[0].setAttribute('src', "");
					setTimeout(function()
						{$('#frameHelp')[0].setAttribute('src', doc)}, 1);
					break;

				case 'goBook':
					var doc = this.link + this.detail + "#" + this.lastInfo;
		console.log(" *** piSchedule - pi.docs.set     goBook: " + "  lastInfo:: " + this.lastInfo + "  doc:: " + doc)

					window.open(doc, 'docu');break;
					break;

				case 'openNews':
					this.lastInfo = "newsplus.html";
					location.replace('static/docs/newsplus.html');
					break;


				default:
					this.lastInfo = info;
					testdoc = "index"

					$.get('/docs?' + testdoc)

					/*---
					this.detail = (sDoc == null) ? this.Overview : this[sDoc]
					var doc = this.link + this.detail + "#" + info;
		console.log(" *** piSchedule - pi.docs.set     default: " + doc  + "  lastInfo:: " + this.lastInfo)


					$('#frameHelp')[0].setAttribute('src', "");
					setTimeout(function() {
						$('#frameHelp')[0].setAttribute('src', doc)}, 100);
					$('#helpModal').modal('show');
					----*/
			}
		}

	}
