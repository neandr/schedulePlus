#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
    Copyright (C) 2015 - 2022 gWahl
"""

#  /cVersion/2022-04-26/

import urllib.request
import json

IP_BASE_URL = "http://ipinfo.io/json"

def getGeoDetails(xp):

    if not 'latitude' in xp:

        with urllib.request.urlopen(IP_BASE_URL) as response:
            rv = json.loads(response.read())

        if (type(rv) is dict):
            xp["longitude"] = (rv["loc"].split(",")[1])[0:7]
            xp["latitude"] = (rv["loc"].split(",")[0])[0:7]

            xp["location"] = str(rv["city"])   #str(rv['city'].encode('utf-8'))
            xp["locale"] = str(rv["country"])
            xp["status"] = response.getcode()
        else:
            xp["status"] = " --- geoDetails (ip) failed to deliver geocoordinates for %s" % (response.getcode())

    return xp

#---------------------------------
if __name__ == "__main__":
    rv = getGeoDetails({})
    print("\n getGeoDetails::",rv)
