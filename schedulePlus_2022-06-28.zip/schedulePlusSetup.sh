#!/bin/bash
GITdoc='https://neandr.github.io/schedulePlus'

NAME='schedulePlus'
VDATE='2021-09-06_2235'
VERSION='3.1'

ZIPP=$NAME.zip

  bw=$'\033[1m'                  # bold
  br=$'\033[1;38;5;196m'         # bold red
  ba=$'\033[1;38;5;16;48;5;15m'  # bold black on white
  bg=$'\033[1;38;5;28;48;5;7m'   # bold green on white
  bb=$'\033[1;38;5;21;48;5;7m'   # bold blue on white
  e0=$'\033[0m'                  # reset/normal

T=" ___ $NAME Setup  #$VERSION     $VDATE ___"
H="
    SYNOPSIS
      schedulePlusSetup.sh [ARGUMENT]

    DESCRIPTION
      Der 'schedulePlus' Programm Code ist verfügbar auf Github als ZIP.
      Verfügbare ZIP/Versionen lassen sich mit diesem Script abrufen und
      vor der Installation erfolgt eine SHA256 Prüfsummen Kontrolle.
      Bei Fehler wird die weitere Script Ausführung abgebrochen.

      Das 'schedulePlus' ZIP wird in das aktuelle Verzeichnis geladen,
      aber in ein übergeordnetes 'schedulePlus/' Verzeichnis entpackt
      und von dort später ausgeführt.

      Der entstehende Verzeichnisbaum:
       ../pi/                      oder ein anderes übergeordnetes Verzeichnis
         |__schedulePlus.zip      ev. weitere Versionen
         |__schedulePlusSetup.sh  dieses Script
         |
         |__schedulePlus/         'schedulePlus' Programm Code

      Dieses Script installiert ebenfalls die erforderlichen Bibliotheken und
      Funktionen um das Ausführen des 'schedulePlus' Programm Code zu ermöglichen.
      Schließlich zeigt es den erforderlichen Aufruf (http://<IP>:<port>)
      für die 'schedulePlus' Ausführung im Browser.

"
A="
    ARGUMENTS
      'no argument'       Zeigt Version/Datum und momentanes Verzeichnis
      '--help'            Prompt dieses 'Help' Textes

      '-l' '--libs'       Laden der Python/bash Bibliotheken (Python, Bottle etc)
      '-i' '--install'    Installation der 'schedulePlus' Funktionen mit Auswahl
                            einer ZIP Datei
      '-c' '--configure'  Konfigurieren des 'schedulePlus' Systems

      '-a' '--all'        Alle erforderlichen Aufrufe ausführen

    Dokumentation  $GITdoc
"


echo "$T"

   xDIR="$(pwd)"
   baseDIR="$(dirname $xDIR)"
   currentDIR="$(basename $xDIR)"

   echo "        xDIR: " $xDIR        #  /home/pi
   echo "     baseDIR: " $baseDIR     #  /home
   echo "  currentDIR: " $currentDIR  #  pi
   #echo " Default ZIP: " $ZIPP        #  $NAME
   echo -e



#----------------------------------------------
function install_it ()
{
   echo "  ... install_it  $WHAT"
   INSTALL_STAT=`sudo pip3 install $WHAT`
   IS_STAT=$(( ! $(grep -iq 'satisfied:' <<< "$INSTALL_STAT"; echo $?) ))
   echo "  ...     status  '$IS_STAT' '$INSTALL_STAT'"
}

function LibsLoad ()
{
   echo -e "\n   *** Load Python libraries for '$NAME'.\n"

   echo "   ... Install python3-pip ..."
   sudo apt-get install python3-pip

   WHAT='apscheduler'
   install_it $WHAT

   WHAT='bottle'
   install_it $WHAT

   WHAT='python-dateutil'
   install_it $WHAT
}

function SystemInstall ()
{
   # unzip code,
   # if directory already exsist, don't extract /data directory
   #   not to overwrite user data, see /data.org for default etc
   echo -e "\n    ---  Checking for '$NAME'"
   if [[ -d $NAME ]] ;  then
      echo -e  "\n!!! ---  '$NAME/' exists already.\n"
      echo -e    "    ---  Code from $ZIPP will be deflated to '$NAME' directory,"
      echo -e    "    ---  excluding '$NAME/data' .. so individual data isn't lost."
      unzip -o $ZIPP -x $NAME/data/* schedulePlusSetup.sh

    else
      echo -e  "\n!!! ---  '$NAME/' .. Does NOT EXISTS! Will be created.\n"
      if ! mkdir $NAME/ ; then
         echo -e "??? ---  '$NAME/' .. Could not create. Error!'"
         exit 102
      else
         echo -e "    ---  '$NAME' code will be installed from '$ZIPP'."
         unzip -o $ZIPP -x schedulePlusSetup.sh
      fi
   fi
}

function SystemConfigure()     #Configure schedulePlus
{
   echo -e "  --- Activate '$xDIR' -- '$NAME' -- "

   chmod 755 $xDIR/schedulePlus.sh

   chmod 755 $xDIR/geoDetails.py
   chmod 755 $xDIR/prefSchedule.py
   chmod 755 $xDIR/schedulePlus.py
   #chmod 755 $NAME/routerAndMe.py
   chmod 755 $xDIR/suntime.py


   #  --- service setup
   if [ -f $xDIR/schedulePlus.sh ] ; then
     sudo service schedulePlus stop 2>/dev/null      # make sure NO schedulePlus is running!

     echo -e " Set the path for schedulePlus.sh"
     sed '/#--DIR--/!b;n;cDIR='"$xDIR" schedulePlus.sh >$xDIR/schedulePlus1.sh
     cp $xDIR/schedulePlus1.sh $xDIR/schedulePlus.sh

   else
     echo -e "\n$br

       NOTE   Missing $NAME components!
              Check the directory for
              >>$NAME/schedulePlus.sh<<
           $e0\n"
     exit 104
   fi


   sudo cp $xDIR/schedulePlus.sh /etc/init.d/schedulePlus
   sudo update-rc.d schedulePlus defaults

   echo -e "System Check ..."
   port=$(sed 's/, "/\n/g' $xDIR/data/jPrefs.json | egrep "port" | tr -d '":a-zA-Z ,')
   addr=$(echo $(hostname -I) | awk '{print $ 1;}')
   echo -e "System Check ... addr: $addr  port:$port  \n\n"


   echo -e "\n

      $ba    Starting 'schedulePlus' now                   $e0

      IMPORTANT if failed ... check with the following commands
      $bg  If not in dir '$xDIR/' change it with:  $e0
      $bw    $ cd $xDIR/           $e0

        $  service schedulePlus status
        $  ./prefSchedule.py
        $  ps ax|grep schedulePlus

      ... see also '$NAME' log-files:
        $  cat logs/piInfo.log
        $  cat logs/piSystem.log

      $bw With valid results  'schedulePlus'  will start.    $e0
      $bw Startup needs a minute, so wait a little before    $e0
      $bw opening 'schedulePlus in the browser with:         $e0

      $ba Press Cntrl and mouse point to this link           $e0
               $bb http://$addr:$port $e0
      $ba 'schedulePlus' shows up in your browser  $bg Enjoy ;) $e0
          (Eventually you have to reload the page)

    "
   sudo service schedulePlus start
   #sudo service schedulePlus status

}


function shatest()
{
   s1=$(cat $ZIPP | sha256sum | head -c 64)
   s2=$(wget  -qO- https://neandr.github.io/schedulePlus/$ZIPP.sha)
   echo -e "   !!!  ZIP Datei SHA256 Check\n"\
   "    abgerufene Datei  : $s1"
   echo -e ""\
   "    Prüfsumme auf GIT : $s2"
   if [[ ! $s1 == $s2 ]] ; then
      echo "$br  ZIP Fehler! Checksum nicht übereinstimmend! $e0"
      exit 1
   fi
}


#==============================================

function zipdocs()
{
   wget  https://api.github.com/repos/neandr/schedulePlus/contents 2>wget.log
   mv contents gitdocs.txt
   Z=$(cat gitdocs.txt |  sed -n '/"path": "docs",/{n;p;}' | sed -e 's/"sha":/ /;s/,//' | xargs )

   X="https://api.github.com/repos/neandr/schedulePlus/git/trees/"$Z
   wget $X 2>>wget.log   # saves to a file named $Z

   # echo "current $Z" #| 2>>wget.log

   mv $Z gitdocs.txt
   cat gitdocs.txt | egrep zip.sha | egrep Plus3 |  sed -e 's/"path"://g;s/[,"]//g;s/.sha//g' > zips.txt
   rm gitdocs.txt

   ls -1 *.py > xx.txt

   n=0
   zips=();
   echo " ................. zips .........."

   while IFS= read -r line; do
      line0=$(echo $line | xargs )
      echo "       $n : [$line0]"
      ((n=n+1))
      zips+=("$line0")
   done < zips.txt
   #rm zips.txt

   read -n 1 -p "      $ba Auswahl der ZIP Datei auf GIT ?   $e0" No ;

   if [[ $No == ?(-)+([0-9]) && ${zips[$No]} ]] ; then
         ZIPP=$(echo ${zips[$No]} | tr -d ' ')
   else
      echo -e "$br No ZIP selected. Terminating! $e0"
      exit 1
   fi

   echo -e  "\n   ---  ZIP für die Installation:  '$ZIPP'"

exit 99

   if [ -f $ZIPP ] ; then
     echo -e "      $ba $ZIPP already exists! $e0"
   else
      #echo "  wget  the zip "
      wget https://neandr.github.io/schedulePlus/$ZIPP 2>>wget.log
   fi
   shatest
}


function unzip_2_tmp()
{  # --- deflate the requested $ZIPP to a tmp directory ---
   if [ -d tmp/ ] ;  then
      echo -e "!!! ---  '/tmp already exists!"

      read -n 1 -p "*** ---  Overwrite  Y/n? " Qa ;
      echo -e  "\n"
       if [[ ! $Qa == 'Y'  ]] ; then
          echo -e  "\n"
          exit 101
       fi

      rm -R tmp/
   fi

   echo -e "    --- unzipp '$ZIPP' to tmp/ directory "
   unzip -o $ZIPP -d tmp/

 exit 0
}

#==============================================

   # Check not to operate on '$NAME' directory,
   # should work on it's parent directory!
   if [[ $currentDIR == '$NAME' ]] ; then
      echo -e "\n!!! ---  Current dir is '$NAME'"
      echo -e   "!!! ---  Script should not be excecuted here!\n"
      exit 1
   fi

   while (( "$#" )); do
     case "$1" in

      -t|--test)
        echo "$T"; exit 0
      ;;

      -s|--system)
       port=$(sed 's/, "/\n/g' $xDIR/data/jPrefs.json | egrep "port" | tr -d '":a-zA-Z ,')
       addr=$(echo $(hostname -I) | awk '{print $ 1;}')
       echo "System Check  addr: $addr  port:$port"
       exit 0
       ;;

      --help)
         echo "$H$A"; exit 0
         ;;


      -l|--libs)
         echo "  ... Bibliotheken laden (Python, Bottle etc ..) ";
         cmd=LibsLoad; shift 1
         ;;

      -i|--install)
         zipdocs
         echo "  ... System installieren mit $ZIPP"
         cmd=SystemInstall; shift 1
         ;;

      -c|--configure)
         echo "  ... System konfigurieren";
         #zipdocs
         cmd=SystemConfigure; shift 1
         #SystemConfigure; shift 1
         ;;

      -a|--all)
         echo "  ... Alles ausführen";
         zipdocs
         LibsLoad
         SystemInstall
         SystemConfigure
         exit 0
         ;;

      --Z)
         zipdocs
         exit 0
         ;;
      *)
         echo "$A"; exit 0
         ;;

     esac
   done
   echo "  ... Aufruf '$cmd' mit ZIP '$ZIPP'"
   $cmd
   rm wget.log 2>/dev/null
   exit 0
